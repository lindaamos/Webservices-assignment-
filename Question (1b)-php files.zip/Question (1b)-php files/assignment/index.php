<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Home Page</title>
</head>
<body bgcolor="Lightblue">
 <nav>
 <a href="index.php">Home</a>
 <a href="about.php">About Us</a>
 <a href="contact.php">Contact Us</a>
 <a href="enquiries.php">Enquiries</a>
 </nav>
 <h1><marquee>Laptops & Cell Phones For Sale.Hurry While Stock Lasts!!!</marquee></h1>
 <img src = "img/Laptop-1.jfif"</img>
 <img src = "img/Laptop 2.jfif"</img>
 <img src = "img/Laptop 3.jfif" height="225" width="223"</img>
 <img src = "img/Laptop 4.jfif" height="225" width="225"</img>
 <img src = "img/Laptop 5.jfif" height="225" width="225"</img>
 <img src = "img/Laptop 6.jfif" height="225" width="225"</img>
 <img src = "img/Phone 1.jfif" height="225" width="225"</img>
 <img src = "img/phone 2.jfif" height="225" width="225"</img>
 <img src = "img/desktop 1.jfif" height="225" width="225"</img>
 <img src="img/desktop 2.jfif" height="225" width="225"</img>
</body>
</html>

    