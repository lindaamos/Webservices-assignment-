<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>About Page</title>
</head>
<body bgcolor="lightblue">
 <nav>
 <a href="index.php">Home</a>
 <a href="about.php">About Us</a>
 <a href="contact.php">Contact Us</a>
 </nav>
 <h1>Welcome to LinTech Technologies</h1>
 <p> We do specialise in electrical and technological gadgets.Hurry while stock lasts!!!</p>
</body>
</html>